FF SUPPORT — BẢN MVP
Chức năng: trang chủ; ghi độ nhạy và ghi chú HUD để xem tóm tắt; đọc mức pin và RAM; checklist luyện tập.
Bản đầu chưa lưu thiết lập lâu dài và không tự áp dụng vào Free Fire. Không có hack/aimbot hoặc can thiệp bộ nhớ game.

CÁCH BUILD APK CHỈ BẰNG ĐIỆN THOẠI:
1. Giải nén ZIP bằng ZArchiver.
2. Mở github.com bằng Chrome và đăng nhập.
3. Tạo repository mới tên FFSupport.
4. Tải lên toàn bộ NỘI DUNG thư mục dự án, giữ nguyên cấu trúc (có thể bật “Trang web cho máy tính”).
5. Vào tab Actions, chọn “Build FF Support APK” và bấm Run workflow.
6. Khi workflow thành công, mở lần chạy đó, xuống Artifacts và tải FF-Support-debug-apk.
7. Giải nén artifact ZIP để lấy app-debug.apk rồi cài trên Android.
Nếu lỗi, vào Actions > lần chạy lỗi và gửi phần log màu đỏ để kiểm tra.

\nTÍNH NĂNG BỔ SUNG — NÚT NỔI:
- Trên trang chủ, bấm “BẬT NÚT NỔI”.
- Android sẽ mở màn hình cấp quyền “Hiển thị trên ứng dụng khác”; bật quyền cho FF Support.
- Quay lại ứng dụng và bấm “BẬT NÚT NỔI” lần nữa.
- Nút tròn xanh “FF” có thể kéo thả; chạm vào sẽ mở FF Support.
- Bấm “TẮT NÚT NỔI” để gỡ nút. Nút này không tự kéo tâm, không mô phỏng thao tác trong Free Fire.
