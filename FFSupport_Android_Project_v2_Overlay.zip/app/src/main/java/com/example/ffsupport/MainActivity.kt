package com.example.ffsupport

import android.app.Activity
import android.os.Bundle
import android.content.Context
import android.graphics.Color
import android.graphics.Typeface
import android.view.Gravity
import android.widget.*

class MainActivity : Activity() {
    private val bg = Color.rgb(9,14,18)
    private val panel = Color.rgb(19,29,34)
    private val neon = Color.rgb(80,255,155)
    private val white = Color.rgb(235,245,240)
    private val muted = Color.rgb(155,177,168)
    private fun dp(n:Int) = (n * resources.displayMetrics.density).toInt()

    override fun onCreate(savedInstanceState: Bundle?) { super.onCreate(savedInstanceState); page("home") }

    private fun page(which:String) {
        val root = LinearLayout(this).apply { orientation=1; setPadding(dp(16),dp(18),dp(16),dp(12)); setBackgroundColor(bg) }
        val scroll = ScrollView(this)
        val body = LinearLayout(this).apply { orientation=1 }
        scroll.addView(body)
        root.addView(scroll, LinearLayout.LayoutParams(-1,0,1f))
        body.addView(TextView(this).apply { text="FF SUPPORT"; textSize=25f; setTextColor(neon); typeface=Typeface.DEFAULT_BOLD; letterSpacing=.1f })
        body.addView(TextView(this).apply { text="GAMING COMPANION • ANDROID"; textSize=11f; setTextColor(muted); setPadding(0,dp(4),0,dp(18)) })
        when(which) {
            "settings" -> settings(body)
            "monitor" -> monitor(body)
            "training" -> training(body)
            else -> home(body)
        }
        val nav = LinearLayout(this).apply { orientation=0 }
        listOf("Home" to "home","Thiết lập" to "settings","Thiết bị" to "monitor","Luyện tập" to "training").forEach { (label,target) ->
            nav.addView(Button(this).apply { text=label; textSize=10f; isAllCaps=false; setTextColor(if(which==target) neon else white); setBackgroundColor(panel); setOnClickListener { page(target) } }, LinearLayout.LayoutParams(0,dp(48),1f).apply { setMargins(dp(2),0,dp(2),0) })
        }
        root.addView(nav); setContentView(root)
    }

    private fun heading(parent:LinearLayout, text:String) {
        parent.addView(TextView(this).apply { this.text=text; textSize=19f; typeface=Typeface.DEFAULT_BOLD; setTextColor(white); setPadding(0,dp(8),0,dp(12)) })
    }
    private fun card(parent:LinearLayout, name:String, desc:String, action:String?=null, run:(()->Unit)?=null) {
        val box=LinearLayout(this).apply { orientation=1; setPadding(dp(14),dp(14),dp(14),dp(14)); setBackgroundColor(panel) }
        box.addView(TextView(this).apply { text=name; textSize=16f; typeface=Typeface.DEFAULT_BOLD; setTextColor(neon) })
        box.addView(TextView(this).apply { text=desc; textSize=13f; setTextColor(white); setPadding(0,dp(6),0,dp(8)) })
        if(action!=null) box.addView(Button(this).apply { text=action; isAllCaps=false; setTextColor(bg); setBackgroundColor(neon); setOnClickListener { run?.invoke() } })
        parent.addView(box,LinearLayout.LayoutParams(-1,-2).apply { setMargins(0,0,0,dp(12)) })
    }
    private fun home(c:LinearLayout) {
        heading(c,"Chào mừng game thủ 👾")
        c.addView(TextView(this).apply { text="Lưu thiết lập • Theo dõi thiết bị • Duy trì lịch luyện tập"; setTextColor(muted); textSize=14f; setPadding(0,0,0,dp(16)) })
        card(c,"01  FF SUPPORT","Lưu độ nhạy và ghi chú HUD do bạn tự nhập.","MỞ THIẾT LẬP"){ page("settings") }
        card(c,"02  FF MONITOR","Xem mức pin và thông tin RAM hệ thống.","KIỂM TRA THIẾT BỊ"){ page("monitor") }
        card(c,"03  FF TRAINING","Checklist luyện ngắm, di chuyển và tiến bộ.","BẮT ĐẦU LUYỆN TẬP"){ page("training") }
        card(c,"04  NÚT NỔI HỖ TRỢ","Bật nút tròn xanh có thể kéo trên màn hình. Chạm nút để mở FF Support; không tự kéo tâm hay can thiệp vào Free Fire.","BẬT NÚT NỔI") {
            if (!android.provider.Settings.canDrawOverlays(this)) {
                val intent = android.content.Intent(android.provider.Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                    android.net.Uri.parse("package:$packageName"))
                startActivity(intent)
                android.widget.Toast.makeText(this,"Hãy cho phép FF Support hiển thị trên ứng dụng khác, rồi quay lại bấm BẬT NÚT NỔI.",android.widget.Toast.LENGTH_LONG).show()
            } else {
                startService(android.content.Intent(this, FloatingButtonService::class.java))
                android.widget.Toast.makeText(this,"Đã bật nút nổi FF màu xanh.",android.widget.Toast.LENGTH_SHORT).show()
            }
        }
        card(c,"TẮT NÚT NỔI","Tắt nút tròn đang hiển thị trên màn hình.","TẮT NÚT NỔI") {
            stopService(android.content.Intent(this, FloatingButtonService::class.java))
            android.widget.Toast.makeText(this,"Đã tắt nút nổi.",android.widget.Toast.LENGTH_SHORT).show()
        }
        c.addView(TextView(this).apply { text="BẢN 1.0 • Không can thiệp vào game"; textSize=11f; setTextColor(muted) })
    }
    private fun settings(c:LinearLayout) {
        heading(c,"Độ nhạy & ghi chú HUD")
        c.addView(TextView(this).apply { text="Nhập giá trị bạn muốn ghi nhớ. Bản đầu chỉ xem tóm tắt, chưa tự áp dụng vào Free Fire."; textSize=13f; setTextColor(muted) })
        val names=listOf("Tổng quan","Red Dot","Ống ngắm 2x","Ống ngắm 4x","Ống ngắm AWM","Nhìn xung quanh")
        val fields= mutableListOf<EditText>()
        names.forEach { name ->
            c.addView(TextView(this).apply { text=name; setTextColor(white); setPadding(0,dp(8),0,dp(3)) })
            val e=EditText(this).apply { hint="Nhập giá trị 0–200"; inputType=android.text.InputType.TYPE_CLASS_NUMBER; setTextColor(white); setHintTextColor(muted); setBackgroundColor(panel); isSingleLine=true }
            c.addView(e,LinearLayout.LayoutParams(-1,dp(48))); fields.add(e)
        }
        c.addView(TextView(this).apply { text="Ghi chú HUD"; setTextColor(white); setPadding(0,dp(12),0,dp(3)) })
        val note=EditText(this).apply { hint="Ví dụ: bố cục 3 ngón..."; minLines=3; gravity=Gravity.TOP; setTextColor(white); setHintTextColor(muted); setBackgroundColor(panel) }
        c.addView(note,LinearLayout.LayoutParams(-1,dp(90)))
        c.addView(Button(this).apply {
            text="XEM TÓM TẮT"; isAllCaps=false; setTextColor(bg); setBackgroundColor(neon)
            setOnClickListener {
                val lines=names.mapIndexed { i,n -> "$n: ${fields[i].text.toString().ifBlank { "chưa nhập" }}" } + "Ghi chú: ${note.text.toString().ifBlank { "chưa có" }}"
                android.app.AlertDialog.Builder(this@MainActivity).setTitle("Thiết lập của bạn").setMessage(lines.joinToString("\n")).setPositiveButton("Đóng",null).show()
            }
        })
    }
    private fun monitor(c:LinearLayout) {
        heading(c,"Thông tin thiết bị")
        val battery=registerReceiver(null,android.content.IntentFilter(android.content.Intent.ACTION_BATTERY_CHANGED))
        val level=battery?.getIntExtra("level",-1) ?: -1
        val scale=battery?.getIntExtra("scale",100) ?: 100
        val pct=if(level>=0 && scale>0) level*100/scale else -1
        val am=getSystemService(Context.ACTIVITY_SERVICE) as android.app.ActivityManager
        val info=android.app.ActivityManager.MemoryInfo(); am.getMemoryInfo(info)
        card(c,"PIN",if(pct>=0) "$pct% pin hiện tại" else "Không đọc được mức pin","LÀM MỚI"){ page("monitor") }
        card(c,"RAM THIẾT BỊ","Tổng RAM khoảng ${info.totalMem/(1024*1024)} MB\nRAM còn trống khoảng ${info.availMem/(1024*1024)} MB")
        card(c,"LƯU Ý","Không thể đảm bảo FPS hoặc tự thay đổi hiệu năng game.")
    }
    private fun training(c:LinearLayout) {
        heading(c,"Checklist luyện tập")
        c.addView(TextView(this).apply { text="Đánh dấu bài sau khi hoàn thành."; textSize=13f; setTextColor(muted); setPadding(0,0,0,dp(12)) })
        listOf("Khởi động ngón tay 3 phút","Luyện kéo tâm ở bia đứng","Luyện di chuyển ngang khi ngắm","Tập đổi vũ khí và nạp đạn","Ghi lại điều cần cải thiện").forEach { task ->
            c.addView(CheckBox(this).apply { text=task; textSize=14f; setTextColor(white); buttonTintList=android.content.res.ColorStateList.valueOf(neon); setPadding(dp(8),dp(8),dp(8),dp(8)); setBackgroundColor(panel) },LinearLayout.LayoutParams(-1,-2).apply { setMargins(0,0,0,dp(8)) })
        }
        card(c,"MẸO","Luyện đều đặn, nghỉ mắt giữa các trận và chơi công bằng.")
    }
}
